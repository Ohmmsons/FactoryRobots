import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SGA {

    private Population population;
    private double pm;
    private double pa;
    private double pr;
    private ArrayList<FiguraGeometrica> obstaculos;

    private Random generator;

    public SGA(double pm, double pa, double pr, int x1, int y1, int x2, int y2, int n, int[] lengths, Random generator, ArrayList<FiguraGeometrica> obstaculos) {
        this.population = new Population(x1, y1, x2, y2, n, lengths, generator,obstaculos);
        this.pm = pm;
        this.pa = pa;
        this.pr = pr;
        this.generator = generator;
        this.obstaculos = obstaculos;
    }

    public Population sga(int g) {
        DecimalFormatSymbols unusualSymbols = new DecimalFormatSymbols();
        unusualSymbols.setDecimalSeparator('.');
        DecimalFormat df = new DecimalFormat("0.00", unusualSymbols);
        for(int i = 0; i<g; i++) {
            population = new Population(population.tournament(), generator, obstaculos);
            ArrayList<Trajetoria> trajetorias = population.getTrajetorias();
            ArrayList<Trajetoria> trajetoriasFilho = new ArrayList<>();
            while (true) {
                int index1 = generator.nextInt(trajetorias.size());
                int index2 = generator.nextInt(trajetorias.size());
                Trajetoria[] filhos = trajetorias.get(index1).crossover(trajetorias.get(index2));
                trajetoriasFilho.add(filhos[0]);
                if (trajetoriasFilho.size() == trajetorias.size()) break;
                trajetoriasFilho.add(filhos[1]);
                if (trajetoriasFilho.size() == trajetorias.size()) break;
            }
            for (Trajetoria t : trajetoriasFilho) {
                t.mutate(pm);
            }
            for (Trajetoria t : trajetoriasFilho) {
                t.addGene(pa);
            }
            for (Trajetoria t : trajetoriasFilho) {
                t.removeGene(pr);
            }
            population = new Population(trajetoriasFilho, generator, obstaculos);
            Trajetoria maxFitness = Collections.max(trajetoriasFilho, (s1, s2) -> (int) Math.signum(s1.fitness() - s2.fitness()));
            Trajetoria minFitness = Collections.min(trajetoriasFilho, (s1, s2) -> (int) Math.signum(s1.fitness() - s2.fitness()));
            Trajetoria minCollision = Collections.min(trajetoriasFilho, (s1, s2) -> (int) Math.signum(s1.nCollisions() - s2.nCollisions()));
            double average = 0;
            for (Trajetoria t : trajetoriasFilho) average += t.fitness();
            average /= trajetorias.size();
            System.out.println(i+": " + df.format(maxFitness.fitness()) + " " + df.format(average) + " " + df.format(minFitness.fitness()) + " " + df.format(minCollision.getLength()) + " " + minCollision.nCollisions());
        }
        return population;
    }
}
